#include "headfile.h"

int main(void)
{
	OLED_Init();
	
	while (1)
	{

	} 
}
